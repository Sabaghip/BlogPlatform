import { EntityRepository, Repository } from "typeorm";
import { SignUpDto } from "./dto/signUp.dto";
import { User } from "./user.entity";

@EntityRepository(User)
export class UserRepository extends Repository<User>{
    async signUp(signUpDto:SignUpDto) : Promise<void>{
        const {username, password} = signUpDto;
        const user = new User();
        user.username = username,
        user.password = password;
        await user.save();
    }
}